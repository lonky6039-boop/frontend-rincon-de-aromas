import React, {useEffect, useState} from 'react'
import ProductCard from '../components/ProductCard'
import api from '../services/api'
export default function Shop(){ const [productos,setProductos]=useState([]); useEffect(()=>{ api.get('/products').then(r=>setProductos(r.data)).catch(()=>{}) },[]); return (<section><h1 className='text-3xl font-semibold mb-4'>Tienda — Rincón de Aromas</h1><div className='grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'>{productos.map(p=><ProductCard key={p.id} product={p}/> )}</div></section>) }
