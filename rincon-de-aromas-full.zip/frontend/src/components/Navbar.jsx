import React from 'react'
import { Link } from 'react-router-dom'
export default function Navbar(){ return (<header style={{background:'#FFF9F5'}} className='shadow'><div className='container mx-auto p-4 flex items-center justify-between'><Link to='/' className='text-2xl font-bold'>RINCÓN DE AROMAS</Link><nav className='flex gap-4 items-center'><Link to='/'>Tienda</Link><Link to='/admin'>Panel Admin</Link><Link to='/login' className='px-3 py-2 rounded' style={{background:'#FADADD'}}>Entrar</Link></nav></div></header>) }
