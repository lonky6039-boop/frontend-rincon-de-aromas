import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import App from './App'
import Shop from './routes/Shop'
import Product from './routes/Product'
import AdminPanel from './routes/AdminPanel'
import Login from './routes/Login'
import './index.css'

if('serviceWorker' in navigator){ window.addEventListener('load', ()=> navigator.serviceWorker.register('/sw.js').catch(()=>{})); }
createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App/>}>
          <Route index element={<Shop/>} />
          <Route path='product/:id' element={<Product/>} />
          <Route path='admin' element={<AdminPanel/>} />
          <Route path='login' element={<Login/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
)
