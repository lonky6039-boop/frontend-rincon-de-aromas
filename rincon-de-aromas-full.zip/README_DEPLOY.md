RINCÓN DE AROMAS — PAQUETE COMPLETO

Contenido:
- frontend/ (React + PWA)
- backend/ (Node/Express + MongoDB + OAuth placeholders + Mercado Pago)

INSTRUCCIONES RÁPIDAS

1) Subir repos a GitHub (recomiendo 2 repos: frontend y backend). Luego conectar repos a Vercel (frontend) y Render (backend).

2) BACKEND — Render
- Crear Web Service en Render, configurar env vars desde backend/.env.example (MONGO_URI, JWT_SECRET, MP_ACCESS_TOKEN, FRONTEND_URL, GOOGLE_CLIENT_ID/SECRET, FACEBOOK_APP_ID/SECRET)

3) FRONTEND — Vercel
- Conectar repo frontend, añadir VITE_API_BASE_URL apuntando al backend en Render.

4) DOMINIO
- Registrar dominio y añadir en Vercel.

5) MERCADO PAGO
- Pegar MP_ACCESS_TOKEN en backend.

6) OAUTH
- Crear credenciales en Google Cloud y Facebook Developers, establecer redirect URIs a https://TU_FRONTEND/auth/google/callback y /auth/facebook/callback

7) PWA
- Para que la app pueda instalarse, servir sobre HTTPS y verificar manifest y icons.

SEGURIDAD
- No publicar tokens en repos públicos.
